Infonet 1.3.1

This is a suite of J-Sim extensions based on the following code from the
Infonet group and revised to be compatible with J-Sim v1.3 patch-1 or later:
- BGP4: infonet-bgp-040203.tar.gz
- MPLS: infonet-mpls-150503.tar.gz
- common utilities: infonet-util-060303.tar.gz
For details, please refer to http://www.info.ucl.ac.be/~bqu/jsim/.

To install it, unpack the package directly onto where J-Sim v1.3 is installed.
Prompt "yes" to any file overrides.  And then recompile the sources.
If "Apache Ant" is used to build the source, no extra step is needed.
If "make" is used, then the following lines (one for each package) need to
be included in $J_SIM/Makefile:
	infonet.javasim.bgp4 \
	infonet.javasim.bgp4.comm \
	infonet.javasim.bgp4.path \
	infonet.javasim.bgp4.policy \
	infonet.javasim.bgp4.timing \
	infonet.javasim.bgp4.util \
	infonet.javasim.FT \
	infonet.javasim.FT.contract \
	infonet.javasim.MPLS \
	infonet.javasim.MPLS.contract \
	infonet.javasim.util \
	infonet.javasim.util.exception \

There are example scripts under script/infonet/.

April 14, 2004
The J-Sim Team

==============================================================================

Change Log

04/14/2004 Infonet 1.3.1
- infonet.javasim.FT.FT.addLabelEntry(): add handling for STOP op
  (pointed out by Muhammad R. Sami, ccse.kfupm.edu.sa)
- add script/infonet/mpls/classic/classic-mpls-3.tcl to test STOP op

03/05/2004 Infonet 1.3
- all Makefiles are revised
- included and revised tracert-1.tcl in infonet-tracert-sample-160603.tar.gz at
  script/infonet/tracert-1.tcl and variation, tracert-2.tcl
- BGP4:
  - bgp4.BGPSession and PeerConnection:
    - remove infonet.javasim.socket.* and use drcl.inet.socket.* instead
    - PeerConnection.handleSocketMessage() changed to dataAvailable()
  - bgp4.BGPSession:
    - remove log_enabled and use isDebugEnabled() instead
    - add setKeepAliveInterval(long) for scripting
    - add static void setSeed(long) to initialize RNG's used
  - bgp4.policy.AtomicPredicate: remove gnu.regexp and use java.util.regex
    instead
  - bgp4.util.Parsing: remove gnu.regexp and use java.util.regex instead
  - pack bgp4.players in zip, seems like it's not used in the current
    implementation
  - include script/infonet/bgp/bgptest.tcl as a sample script
- MPLS:
  - MPLS.LSPacket: remove duplicate()
  - MPLS.Label: added toString()
  - MPLS.MPLS:
    - comment out verbose print-out, one can use the trace and garbagedisplay
      facilities from J-Sim instead
    - convert some error() to drop()
    - handleInetPacket()
      - if no ftentry for the pkt, just forward it to pktdispatcher;
        no error reported
      - if result of resolving InetPacket is not LSPacket, just forward it
        to pktdispatcher; no error reported
      - no returning false so change return type to void
    - sendInetPacket()
      - renamed to sendUp(): for cases where the pkt may not be InetPacket
      - change argument type from InetPacket to Object;
      - remove fte_ argument
    - dataArriveAtDownPort: use IDLookup.query() instead of IDLookup.getAllIDs()
      and linear matching of the destination address
    - replace a couple of places with sendInetPacket()
    - constructPacket()
      - renamed to resolvePacket()
      - return type changed to Object
      - dont need to distinguish InetPacket out: remove code for "isInetPkt"
    - include scripts from infonet-mpls-sample-150503.tar.gz at
      script/infonet/mpls/
      - revised to take advantage of drcl.inet.InetUtil.connectNeighbors()
        and drcl.inet.TraceRT


